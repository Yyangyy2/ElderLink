plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.google.gms.google.services)
}

// Load .env properties (optional) so sensitive keys can be stored outside VCS
val envFile = rootProject.file(".env")
val geminiApiKeyFromEnv: String? = if (envFile.exists()) {
    envFile.readLines()
        .map { it.trim() }
        .firstOrNull { it.startsWith("GEMINI_API_KEY=") }
        ?.substringAfter("=")
} else null
val geminiApiKey: String? = geminiApiKeyFromEnv ?: System.getenv("GEMINI_API_KEY")

android {
    namespace = "com.example.elderlink"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.elderlink"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Expose the GEMINI API key to the app via BuildConfig (empty string if not provided)
        buildConfigField("String", "GEMINI_API_KEY", "\"${geminiApiKey ?: ""}\"")
    }

    buildTypes {
        debug {
            // prevent debug suffix
            applicationIdSuffix = ""
            versionNameSuffix = ""
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.firebase.database)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.firebase.auth)
    implementation(libs.androidx.recyclerview)
    implementation(libs.material)
    implementation("com.github.bumptech.glide:glide:4.16.0")
    implementation(libs.firebase.storage)
    implementation(libs.firebase.firestore)
    annotationProcessor("com.github.bumptech.glide:compiler:4.16.0")
    //implementation ("com.google.ai.client:generativelanguage:0.7.0")
    implementation ("com.squareup.okhttp3:okhttp:4.11.0")
    implementation ("com.google.code.gson:gson:2.10.1")
    implementation ("com.squareup.picasso:picasso:2.71828")
    implementation ("com.google.firebase:firebase-messaging:23.4.1")
    implementation ("org.osmdroid:osmdroid-android:6.1.18")
    implementation ("com.google.firebase:firebase-firestore:25.0.0")
    implementation ("com.google.android.gms:play-services-location:21.0.1")






    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}

